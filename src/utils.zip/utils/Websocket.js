// composables/useWebSocket.js
import { ref, onUnmounted, watchEffect } from 'vue'

export function useWebSocket(url, { onMessage } = {}) {
  const ws = ref(null)
  const isConnected = ref(false)
  const message = ref(null)
  let reconnectTimer = null
  let heartbeatTimer = null

  const connect = () => {
    if (ws.value) return

    ws.value = new WebSocket(url)

    ws.value.onopen = () => {
      isConnected.value = true
      startHeartbeat()
      console.log('[WebSocket] ✅ 已连接')
    }

    ws.value.onmessage = (event) => {
      message.value = event.data
      onMessage?.(event.data)
    }

    ws.value.onclose = () => {
      console.log('[WebSocket] ❌ 断开，尝试重连...')
      isConnected.value = false
      stopHeartbeat()
      reconnect()
    }

    ws.value.onerror = (e) => {
      console.error('[WebSocket] 错误:', e)
    }
  }

  const reconnect = () => {
    clearTimeout(reconnectTimer)
    reconnectTimer = setTimeout(() => {
      ws.value = null
      connect()
    }, 3000) // 3秒后重连
  }

  const startHeartbeat = () => {
    clearInterval(heartbeatTimer)
    heartbeatTimer = setInterval(() => {
      if (ws.value && ws.value.readyState === WebSocket.OPEN) {
        ws.value.send('ping')
      }
    }, 10000)
  }

  const stopHeartbeat = () => {
    clearInterval(heartbeatTimer)
  }

  const close = () => {
    stopHeartbeat()
    clearTimeout(reconnectTimer)
    if (ws.value) {
      ws.value.close()
      ws.value = null
    }
  }

  onUnmounted(() => {
    close()
  })

  return {
    connect,
    close,
    isConnected,
    message,
  }
}

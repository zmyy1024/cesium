import * as Cesium from 'cesium'

export function startModelMoverToFixedTarget(viewer, modelEntity, targetPositionRef) {
  if (!viewer || !modelEntity || !isValidTarget(targetPositionRef)) {
    console.warn('[modelMover] 参数不合法')
    return
  }

  const height = typeof targetPositionRef.height === 'number' ? targetPositionRef.height : 0
  const newCartesian = Cesium.Cartesian3.fromDegrees(
    targetPositionRef.lng,
    targetPositionRef.lat,
    height
  )

  // 初始化轨迹点数组
  if (!Array.isArray(modelEntity._trackPoints)) {
    modelEntity._trackPoints = []
  }

  // 添加当前位置作为一个轨迹点
  modelEntity._trackPoints.push(newCartesian)

  // 创建或更新轨迹线实体
  if (!modelEntity._trackLineEntity) {
    modelEntity._trackLineEntity = viewer.entities.add({
      polyline: {
        positions: new Cesium.CallbackProperty(() => {
          return modelEntity._trackPoints
        }, false),
        width: 2,
        material: Cesium.Color.RED.withAlpha(0.9),
        clampToGround: false
      }
    })
  }

  // 更新模型位置
  if (!(modelEntity.position instanceof Cesium.ConstantPositionProperty)) {
    modelEntity.position = new Cesium.ConstantPositionProperty(newCartesian)
  } else {
    modelEntity.position.setValue(newCartesian)
  }
}

function isValidTarget(pos) {
  return pos &&
    typeof pos.lng === 'number' &&
    typeof pos.lat === 'number'
}
